# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from resources.lib.modules.control import addonPath, addonId, getLEVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get(file):
	le_path = addonPath(addonId())
	le_version = getLEVersion()
	helpFile = joinPath(le_path, 'resources', 'help', file + '.txt')
	r = open(helpFile)
	text = r.read()
	r.close()
	heading = '[B]LE -  v%s - %s[/B]' % (le_version, file)
	windows = TextViewerXML('textviewer.xml', le_path, heading=heading, text=text)
	windows.run()
	del windows