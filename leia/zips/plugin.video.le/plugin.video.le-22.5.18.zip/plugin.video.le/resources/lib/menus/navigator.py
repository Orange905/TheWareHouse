# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from sys import argv, exit as sysexit
try: #Py2
    from urllib import quote_plus
except ImportError:  #Py3
    from urllib.parse import quote_plus
from resources.lib.modules import control
from resources.lib.modules.trakt import getTraktCredentialsInfo, getTraktIndicatorsInfo


movielist1 = control.setting('tmdb.movielist_name1')
movielist2 = control.setting('tmdb.movielist_name2')
movielist3 = control.setting('tmdb.movielist_name3')
movielist4 = control.setting('tmdb.movielist_name4')
movielist5 = control.setting('tmdb.movielist_name5')
movielist6 = control.setting('tmdb.movielist_name6')
movielist7 = control.setting('tmdb.movielist_name7')
movielist8 = control.setting('tmdb.movielist_name8')
movielist9 = control.setting('tmdb.movielist_name9')
movielist10 = control.setting('tmdb.movielist_name10')

tvlist1 = control.setting('tmdb.tvlist_name1')
tvlist2 = control.setting('tmdb.tvlist_name2')
tvlist3 = control.setting('tmdb.tvlist_name3')
tvlist4 = control.setting('tmdb.tvlist_name4')
tvlist5 = control.setting('tmdb.tvlist_name5')
tvlist6 = control.setting('tmdb.tvlist_name6')
tvlist7 = control.setting('tmdb.tvlist_name7')
tvlist8 = control.setting('tmdb.tvlist_name8')
tvlist9 = control.setting('tmdb.tvlist_name9')
tvlist10 = control.setting('tmdb.tvlist_name10')

mymovlist1 = control.setting('tmdb.mymovlist_name1')
mymovlist2 = control.setting('tmdb.mymovlist_name2')
mymovlist3 = control.setting('tmdb.mymovlist_name3')
mymovlist4 = control.setting('tmdb.mymovlist_name4')
mymovlist5 = control.setting('tmdb.mymovlist_name5')
mymovlist6 = control.setting('tmdb.mymovlist_name6')
mymovlist7 = control.setting('tmdb.mymovlist_name7')
mymovlist8 = control.setting('tmdb.mymovlist_name8')
mymovlist9 = control.setting('tmdb.mymovlist_name9')
mymovlist10 = control.setting('tmdb.mymovlist_name10')

mytvlist1 = control.setting('tmdb.mytvlist_name1')
mytvlist2 = control.setting('tmdb.mytvlist_name2')
mytvlist3 = control.setting('tmdb.mytvlist_name3')
mytvlist4 = control.setting('tmdb.mytvlist_name4')
mytvlist5 = control.setting('tmdb.mytvlist_name5')
mytvlist6 = control.setting('tmdb.mytvlist_name6')
mytvlist7 = control.setting('tmdb.mytvlist_name7')
mytvlist8 = control.setting('tmdb.mytvlist_name8')
mytvlist9 = control.setting('tmdb.mytvlist_name9')
mytvlist10 = control.setting('tmdb.mytvlist_name10')
class Navigator:
    def __init__(self):
        self.artPath = control.artPath()
        self.iconLogos = control.setting('icon.logos') != 'Traditional'
        self.indexLabels = control.setting('index.labels') == 'true'
        self.traktCredentials = getTraktCredentialsInfo()
        self.traktIndicators = getTraktIndicatorsInfo()
        self.imdbCredentials = control.setting('imdb.user') != ''
        self.tmdbSessionID = control.setting('tmdb.session_id') != ''

    def root(self):
        self.addDirectoryItem(33046, 'movieNavigator', 'movies.png', 'DefaultMovies.png')
        self.addDirectoryItem(33047, 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')

        if control.getMenuEnabled('mylists.widget'):
            self.addDirectoryItem(32003, 'mymovieNavigator', 'mymovies.png', 'DefaultVideoPlaylists.png')
            self.addDirectoryItem(32004, 'mytvNavigator', 'mytvshows.png', 'DefaultVideoPlaylists.png')
        if control.setting('furk.api') != '' and control.getMenuEnabled('navi.furk') : self.addDirectoryItem('Furk.net', 'furkNavigator', 'movies.png', 'DefaultMovies.png')

        if control.getMenuEnabled('navi.main.lelists'):
            self.addDirectoryItem('Loonatics Movie Lists', 'listsListsNavigator', 'lists.png', 'DefaultMovies.png')

        if control.getMenuEnabled('navi.main.iptv'):
            self.addDirectoryItem('IPTV & Sports', 'iptvListsNavigator', 'iptv.png', 'DefaultTVShows.png')

        if control.getMenuEnabled('navi.main.originals'):
            self.addDirectoryItem(40077 if self.indexLabels else 40070, 'tvOriginals', 'tvmaze.png' if self.iconLogos else 'netamahu.png', 'DefaultNetwork.png')

        if control.getMenuEnabled('navi.main.tmdb'):
            self.addDirectoryItem('TMDB Movie Arena', 'tmdbnavigator', 'tmdb.png', 'DefaultMovies.png')

        if control.getMenuEnabled('navi.main.imdb'):
            self.addDirectoryItem('IMDB Movie Arena', 'imdbnavigator', 'imdb.png', 'DefaultMovies.png')

        if control.getMenuEnabled('navi.main.docs'):
            self.addDirectoryItem('Documentaries', 'movies&url=docs', 'docs.png', 'DefaultMovies.png')

        if control.getMenuEnabled('navi.main.anime'):
            self.addDirectoryItem('Anime', 'anime_Navigator', 'anime.png', 'DefaultFolder.png')

        if control.getMenuEnabled('navi.main.cartoons'):
            self.addDirectoryItem(30808, 'tvshows&url=https://api.trakt.tv/users/sg0/lists/sg0-s-toontv/items', 'retrotoons.png', 'DefaultTVShows.png')

        #if control.getMenuEnabled('navi.main.music'):
            #self.addDirectoryItem(30809, 'musicNavigator', 'music.png', 'DefaultTVShows.png')

        if control.getMenuEnabled('navi.main.music'):
            self.addDirectoryItem(30809, 'music', 'music.png', 'DefaultTVShows.png')

        if control.getMenuEnabled('navi.main.standup'):
            self.addDirectoryItem(30810, 'movies&url=https://api.trakt.tv/users/giladg/lists/stand-up-comedy/items', 'standup.png', 'DefaultTVShows.png')

        if control.getMenuEnabled('navi.youtube'):
            self.addDirectoryItem('You Tube Videos', 'youtube', 'youtube.png', 'youtube.png')

        adult = True if control.setting('adult_pw') == 'yen00L' else False
        if adult == True:
            self.addDirectoryItem('Adult Cartoons', 'tvshows&url=https://api.trakt.tv/users/sirmax/lists/bad-toontv/items', 'adults.png', 'DefaultTVShows.png')
            self.addDirectoryItem(30819, 'porn', 'adults.png', 'DefaultTVShows.png')

        self.addDirectoryItem(32010, 'tools_searchNavigator', 'search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
        if downloads: self.addDirectoryItem(32009, 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')
        if control.getMenuEnabled('navi.prem.services'): self.addDirectoryItem('Premium Services', 'premiumNavigator', 'premium.png', 'DefaultFolder.png')
        if control.getMenuEnabled('navi.news'): self.addDirectoryItem(32013, 'tools_ShowNews', 'icon.png', 'DefaultAddonHelper.png', isFolder=False)
        if control.getMenuEnabled('navi.changelog'): self.addDirectoryItem(32014, 'tools_ShowChangelog', 'icon.png', 'DefaultAddonsUpdates.png', isFolder=False)
        self.endDirectory()

    def furk(self):
        self.addDirectoryItem('User Files', 'furkUserFiles', 'userlists.png', 'DefaultVideoPlaylists.png')
        self.addDirectoryItem('Search', 'furkSearch', 'search.png', 'search.png')
        self.endDirectory()

    def movies(self, lite=False):
        if control.getMenuEnabled('navi.movie.imdb.intheater'):
            self.addDirectoryItem(32421 if self.indexLabels else 32420, 'movies&url=theaters', 'imdb.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.trakt.anticipated'):
            self.addDirectoryItem(32425 if self.indexLabels else 32424, 'movies&url=traktanticipated', 'trakt.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.boxoffice'):
            self.addDirectoryItem(32435 if self.indexLabels else 32434, 'movies&url=imdbboxoffice', 'imdb.png' if self.iconLogos else 'box-office.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.boxoffice'):
            self.addDirectoryItem(32436 if self.indexLabels else 32434, 'tmdbmovies&url=tmdb_boxoffice', 'tmdb.png' if self.iconLogos else 'box-office.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.trakt.boxoffice'):
            self.addDirectoryItem(32437 if self.indexLabels else 32434, 'movies&url=traktboxoffice', 'trakt.png' if self.iconLogos else 'box-office.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.certificates'):
            self.addDirectoryItem(32464 if self.indexLabels else 32463, 'movieCertificates', 'imdb.png' if self.iconLogos else 'certificates.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.collections'):
            self.addDirectoryItem(32000, 'collections_Navigator', 'boxsets.png', 'DefaultSets.png')
        if control.getMenuEnabled('navi.movie.imdb.featured'):
            self.addDirectoryItem(32447 if self.indexLabels else 32446, 'movies&url=featured', 'imdb.png' if self.iconLogos else 'movies.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.genres'):
            self.addDirectoryItem(32456 if self.indexLabels else 32455, 'movieGenres', 'imdb.png' if self.iconLogos else 'genres.png', 'DefaultGenre.png')

        if control.getMenuEnabled('navi.movie.imdb.languages'):
            self.addDirectoryItem(32462 if self.indexLabels else 32461, 'movieLanguages', 'imdb.png' if self.iconLogos else 'languages.png', 'DefaultAddonLanguage.png')
        if control.getMenuEnabled('navi.movie.most'):
            self.addDirectoryItem('Most Played / Collected / Watched', 'movieMosts', 'people-watching.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.popular'):
            self.addDirectoryItem(32429 if self.indexLabels else 32428, 'movies&url=mostpopular', 'imdb.png' if self.iconLogos else 'most-popular.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.mostvoted'):
            self.addDirectoryItem(32439 if self.indexLabels else 32438, 'movies&url=mostvoted', 'imdb.png' if self.iconLogos else 'most-voted.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.nowplaying'):
            self.addDirectoryItem(32423 if self.indexLabels else 32422, 'tmdbmovies&url=tmdb_nowplaying', 'tmdb.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.oscarwinners'):
            self.addDirectoryItem(32452 if self.indexLabels else 32451, 'movies&url=oscars', 'imdb.png' if self.iconLogos else 'oscar-winners.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.oscarnominees'):
            self.addDirectoryItem(32454 if self.indexLabels else 32453, 'movies&url=oscarsnominees', 'imdb.png' if self.iconLogos else 'oscar-winners.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.people'):
            self.addDirectoryItem(32460 if self.indexLabels else 32459, 'moviePersons', 'imdb.png' if self.iconLogos else 'people.png', 'DefaultActor.png')
        if control.getMenuEnabled('navi.movie.tmdb.popular'):
            self.addDirectoryItem(32431 if self.indexLabels else 32430, 'tmdbmovies&url=tmdb_popular', 'tmdb.png' if self.iconLogos else 'most-popular.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.trakt.popular'):
            self.addDirectoryItem(32433 if self.indexLabels else 32432, 'movies&url=traktpopular', 'trakt.png' if self.iconLogos else 'most-popular.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.trakt.recommended'):
            self.addDirectoryItem(32445 if self.indexLabels else 32444, 'movies&url=traktrecommendations', 'trakt.png' if self.iconLogos else 'highly-rated.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.toprated'):
            self.addDirectoryItem(32441 if self.indexLabels else 32440, 'tmdbmovies&url=tmdb_toprated', 'tmdb.png' if self.iconLogos else 'most-voted.png', 'DefaultMovies.png')
        #if control.getMenuEnabled('navi.movie.channels'):
            #self.addDirectoryItem(30807, 'channels', 'channels.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.trakt.trending'):
            self.addDirectoryItem(32443 if self.indexLabels else 32442, 'movies&url=trakttrending', 'trakt.png' if self.iconLogos else 'trending.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.upcoming'):
            self.addDirectoryItem(32427 if self.indexLabels else 32426, 'tmdbmovies&url=tmdb_upcoming', 'tmdb.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.years'):
            self.addDirectoryItem(32458 if self.indexLabels else 32457, 'movieYears', 'imdb.png' if self.iconLogos else 'years.png', 'DefaultYear.png')
        if not lite:
            if control.getMenuEnabled('mylists.widget'):
                self.addDirectoryItem(32003, 'mymovieliteNavigator', 'mymovies.png', 'DefaultMovies.png')
            self.addDirectoryItem(33044, 'moviePerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(33042, 'movieSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def movieMosts(self, lite=False):
        self.addDirectoryItem('Most Played This Week', 'movies&url=played1', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Played This Month', 'movies&url=played2', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Played This Year', 'movies&url=played3', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Played All Time', 'movies&url=played4', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Collected This Week', 'movies&url=collected1', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Collected This Month', 'movies&url=collected2', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Collected This Year', 'movies&url=collected3', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Collected All Time', 'movies&url=collected4', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Watched This Week', 'movies&url=watched1', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Watched This Month', 'movies&url=watched2', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Watched This Year', 'movies&url=watched3', 'most-popular.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Watched All Time', 'movies&url=watched4', 'most-popular.png', 'DefaultMovies.png')
        self.endDirectory()

    def mymovies(self, lite=False):
        self.accountCheck()
        self.addDirectoryItem(32039, 'movieUserlists', 'userlists.png', 'DefaultVideoPlaylists.png')
        if self.traktCredentials:
            if self.traktIndicators:
                self.addDirectoryItem(35308, 'moviesUnfinished&url=traktunfinished', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True)
                self.addDirectoryItem(32036, 'movies&url=trakthistory', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True)
            self.addDirectoryItem(32683, 'movies&url=traktwatchlist', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True, context=(32551, 'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist'))
            self.addDirectoryItem(32032, 'movies&url=traktcollection', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True, context=(32551, 'library_moviesToLibrary&url=traktcollection&name=traktcollection'))
        if self.imdbCredentials: self.addDirectoryItem(32682, 'movies&url=imdbwatchlist', 'imdb.png', 'DefaultVideoPlaylists.png', queue=True)
        if not lite:
            self.addDirectoryItem('Discover Movies', 'movieliteNavigator', 'movies.png', 'DefaultMovies.png') #32031
            self.addDirectoryItem(33044, 'moviePerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(33042, 'movieSearch', 'search.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def tvshows(self, lite=False):
        if control.getMenuEnabled('navi.tv.imdb.newtvshows'):
            self.addDirectoryItem(32476 if self.indexLabels else 32475, 'tvshows&url=premiere', 'imdb.png' if self.iconLogos else 'new-tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
        if control.getMenuEnabled('navi.tv.trakt.anticipated'):
            self.addDirectoryItem('Anticipated', 'tvshows&url=traktanticipated', 'tvshows.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.imdb.airingtoday'):
            self.addDirectoryItem(32466 if self.indexLabels else 32465, 'tvshows&url=airing', 'imdb.png' if self.iconLogos else 'airing-today.png', 'DefaultRecentlyAddedEpisodes.png')
        if control.getMenuEnabled('navi.tv.tmdb.airingtoday'):
            self.addDirectoryItem(32467 if self.indexLabels else 32465, 'tmdbTvshows&url=tmdb_airingtoday', 'tmdb.png' if self.iconLogos else 'airing-today.png', 'DefaultRecentlyAddedEpisodes.png')
        if control.getMenuEnabled('navi.tv.tvmaze.calendar'):
            self.addDirectoryItem(32450 if self.indexLabels else 32027, 'calendars', 'tvmaze.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
        if control.getMenuEnabled('navi.tv.imdb.certificates'):
            self.addDirectoryItem(32464 if self.indexLabels else 32463, 'tvCertificates', 'imdb.png' if self.iconLogos else 'certificates.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.imdb.genres'):
            self.addDirectoryItem(32456 if self.indexLabels else 32455, 'tvGenres', 'imdb.png' if self.iconLogos else 'genres.png', 'DefaultGenre.png')
        if control.getMenuEnabled('navi.tv.imdb.highlyrated'):
            self.addDirectoryItem(32449 if self.indexLabels else 32448, 'tvshows&url=rating', 'imdb.png' if self.iconLogos else 'highly-rated.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.imdb.languages'):
            self.addDirectoryItem(32462 if self.indexLabels else 32461, 'tvLanguages', 'imdb.png' if self.iconLogos else 'languages.png', 'DefaultAddonLanguage.png')
        if control.getMenuEnabled('navi.tv.most'):
            self.addDirectoryItem('Most Played / Collected / Watched', 'showMosts', 'people-watching.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.imdb.popular'):
            self.addDirectoryItem(32429 if self.indexLabels else 32428, 'tvshows&url=popular', 'imdb.png' if self.iconLogos else 'most-popular.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.imdb.mostvoted'):
            self.addDirectoryItem(32439 if self.indexLabels else 32438, 'tvshows&url=views', 'imdb.png' if self.iconLogos else 'most-voted.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.tvmaze.networks'):
            self.addDirectoryItem(32468 if self.indexLabels else 32469, 'tvNetworks', 'tvmaze.png' if self.iconLogos else 'networks.png', 'DefaultNetwork.png')

        if control.getMenuEnabled('navi.tv.tmdb.ontv'):
            self.addDirectoryItem(32472 if self.indexLabels else 32471, 'tmdbTvshows&url=tmdb_ontheair', 'tmdb.png' if self.iconLogos else 'new-tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
        if control.getMenuEnabled('navi.tv.tmdb.popular'):
            self.addDirectoryItem(32431 if self.indexLabels else 32430, 'tmdbTvshows&url=tmdb_popular', 'tmdb.png' if self.iconLogos else 'most-popular.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.trakt.popular'):
            self.addDirectoryItem(32433 if self.indexLabels else 32432, 'tvshows&url=traktpopular', 'trakt.png' if self.iconLogos else 'most-popular.png', 'DefaultTVShows.png', queue=True)
        if control.getMenuEnabled('navi.tv.trakt.recommended'):
            self.addDirectoryItem(32445 if self.indexLabels else 32444, 'tvshows&url=traktrecommendations', 'trakt.png' if self.iconLogos else 'highly-rated.png', 'DefaultTVShows.png', queue=True)
        if control.getMenuEnabled('navi.tv.imdb.returningtvshows'):
            self.addDirectoryItem(32474 if self.indexLabels else 32473, 'tvshows&url=active', 'imdb.png' if self.iconLogos else 'returning-tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
        if control.getMenuEnabled('navi.tv.tmdb.toprated'):
            self.addDirectoryItem(32441 if self.indexLabels else 32440, 'tmdbTvshows&url=tmdb_toprated', 'tmdb.png' if self.iconLogos else 'most-voted.png', 'DefaultTVShows.png')
        if control.getMenuEnabled('navi.tv.trakt.trending'):
            self.addDirectoryItem(32443 if self.indexLabels else 32442, 'tvshows&url=trakttrending', 'trakt.png' if self.iconLogos else 'trending.png', 'DefaultTVShows.png')
        if not lite:
            if control.getMenuEnabled('mylists.widget'):
                self.addDirectoryItem(32004, 'mytvliteNavigator', 'mytvshows.png', 'DefaultTVShows.png')
            self.addDirectoryItem(33045, 'tvPerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(33043, 'tvSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def showMosts(self, lite=False):
        self.addDirectoryItem('Most Played This Week', 'tvshows&url=played1', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Played This Month', 'tvshows&url=played2', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Played This Year', 'tvshows&url=played3', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Played All Time', 'tvshows&url=played4', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Collected This Week', 'tvshows&url=collected1', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Collected This Month', 'tvshows&url=collected2', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Collected This Year', 'tvshows&url=collected3', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Collected All Time', 'tvshows&url=collected4', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Watched This Week', 'tvshows&url=watched1', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Watched This Month', 'tvshows&url=watched2', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Watched This Year', 'tvshows&url=watched3', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Watched All Time', 'tvshows&url=watched4', 'most-popular.png', 'DefaultTVShows.png')
        self.endDirectory()

    def mytvshows(self, lite=False):
        self.accountCheck()
        self.addDirectoryItem(32040, 'tvUserlists', 'userlists.png', 'DefaultVideoPlaylists.png')
        if self.traktCredentials:
            if self.traktIndicators:
                self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'trakt.png', 'DefaultVideoPlaylists.png', context=(32551, 'library_tvshowsToLibrary&url=traktcollection&name=traktcollection'))
                self.addDirectoryItem(32037, 'calendar&url=progress', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True)
                self.addDirectoryItem(35308, 'episodesUnfinished&url=traktunfinished', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True)
                self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True)
                self.addDirectoryItem(32019, 'upcomingProgress&url=progress', 'trakt.png', 'DefaultVideoPlaylists.png', queue=True)
                self.addDirectoryItem(32027, 'calendar&url=mycalendar', 'trakt.png', 'DefaultYear.png', queue=True)
            self.addDirectoryItem(32683, 'tvshows&url=traktwatchlist', 'trakt.png', 'DefaultVideoPlaylists.png', context=(32551, 'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist'))
            self.addDirectoryItem(32041, 'episodesUserlists', 'userlists.png', 'DefaultVideoPlaylists.png')
        if self.imdbCredentials: self.addDirectoryItem(32682, 'tvshows&url=imdbwatchlist', 'imdb.png', 'DefaultVideoPlaylists.png')
        if not lite:
            self.addDirectoryItem('Discover TV Shows', 'tvliteNavigator', 'tvshows.png', 'DefaultTVShows.png') #32031
            self.addDirectoryItem(33045, 'tvPerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(33043, 'tvSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
            self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def anime(self, lite=False):
        self.addDirectoryItem(32001, 'anime_Movies&url=anime', 'animemovie.png', 'DefaultMovies.png')
        self.addDirectoryItem(32002, 'anime_TVshows&url=anime', 'animetv.png', 'DefaultTVShows.png')
        self.endDirectory()


    def iptv(self, lite=False):
        self.addDirectoryItem(30802, 'swifttv', 'swifttv.png', 'DefaultTVShows.png')
        self.addDirectoryItem(30803, 'taptv', 'taptv.png', 'DefaultTVShows.png')
        self.addDirectoryItem(30806, 'lntv', 'lntv.png', 'DefaultTVShows.png')
        self.addDirectoryItem('RBTv - [COLOR red]19 Only[/COLOR]', 'rbtv', 'rbtv.png', 'DefaultTVShows.png')
        self.addDirectoryItem('USGoTv - [COLOR red]19 Only[/COLOR]', 'usgotv', 'usgotv.png', 'DefaultTVShows.png')
        self.addDirectoryItem(30804, 'm3u', 'm3u.png', 'DefaultTVShows.png')
        self.addDirectoryItem('IPTV Test Arena', 'test', 'icon.png', 'DefaultTVShows.png')
        self.endDirectory()


    def lists(self, lite=False):
        self.addDirectoryItem(30834, 'madhouseListsNavigator', 'madicon.png', 'lists.png')
        self.addDirectoryItem(30835, 'dcmarvelherosNavigator', 'dcmarvelheros.png', 'DefaultMovies.png')
        self.addDirectoryItem('1Click Movies [COLORspringgreen](FREE)[/COLOR]', 'oneclick', 'movies.png', 'DefaultMovies.png')
        self.endDirectory()

    def madhouse(self, lite=False):
        #self.addDirectoryItem('DiamondBuild [COLORred](RD ONLY)[/COLOR]', 'diamondbuild', 'diamondbuild.png', 'DefaultMovies.png')
        self.addDirectoryItem('Insomnia 1Click [COLORred](RD ONLY)[/COLOR]', 'ioneclick', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('Insomnia 1Click Horror [COLORred](RD ONLY)[/COLOR]', 'ihorror', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('NightWing 1Click New Releases [COLORred](RD ONLY)[/COLOR]', 'magnetic', 'nightwing.png', 'DefaultMovies.png')
        #self.addDirectoryItem(30829, 'userlists', 'userlist.png', 'lists.png')
        self.addDirectoryItem('DcMarvelBuild Top 4K Movies', 'movies&url=dcmarvelbuild', 'dcmarvelbuild.png', 'DefaultMovies.png')
        self.addDirectoryItem('WolfGirl', 'wolfgirl', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Cable', 'cable', 'cable.png', 'DefaultMovies.png')
        self.addDirectoryItem('ShadowHawk', 'shadowhawk', 'shadowhawk.png', 'DefaultMovies.png')
        self.addDirectoryItem('Insomnia', 'insomnia', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('DocOctyl', 'dococtyl', 'dococtyl.png', 'DefaultMovies.png')
        self.addDirectoryItem('BurninU', 'burninu', 'burninu.png', 'DefaultMovies.png')
        self.endDirectory()


    def wolfgirl(self, lite=False):
        self.addDirectoryItem('[COLORmediumpurple]Wolfs Picks[/COLOR] - [COLORmediumorchid]Updated Monthly[/COLOR]', 'movies&url=wgpicks', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Action', 'movies&url=wgaction', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Apocolypse', 'movies&url=wgapocolypse', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Christmas', 'movies&url=wgxmas', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Comedy', 'movies&url=wgcomedy', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Documentaries', 'movies&url=wgdocs', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('James Bond', 'movies&url=wgbond', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Halloween', 'movies&url=wgsleepy', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Monster', 'movies&url=wgmonster', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Paranormal', 'movies&url=wgparanormal', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Toons', 'movies&url=wgtoons', 'wolfgirl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Vault', 'movies&url=wgvault', 'wolfgirl.png', 'DefaultMovies.png')
        self.endDirectory()

    def cable(self):
        self.addDirectoryItem('Hot & Spicy Movies', 'movies&url=cablemovie', 'cable.png', 'DefaultMovies.png')
        #self.addDirectoryItem('NAME2', 'movies&url=cableNAME2', 'cable.png', 'DefaultMovies.png')
        self.addDirectoryItem('Hot & Spicy TvShows', 'tvshows&url=cabletv', 'cable.png', 'DefaultMovies.png')
        self.endDirectory()

    def shadowhawk(self, lite=False):
        self.addDirectoryItem('Jay & Silent Bob', 'movies&url=shjaysilentbob', 'shadowhawk.png', 'DefaultMovies.png')
        self.addDirectoryItem('Stoner Movies', 'movies&url=shstonermovies', 'shadowhawk.png', 'DefaultMovies.png')
        self.addDirectoryItem('Monty Python', 'movies&url=shmontypython', 'shadowhawk.png', 'DefaultMovies.png')
        self.addDirectoryItem('Chech & Chong', 'movies&url=shchechchong', 'shadowhawk.png', 'DefaultMovies.png')
        self.addDirectoryItem('Stoner Tv Shows', 'tvshows&url=shstonertvshows', 'shadowhawk.png', 'DefaultTVShows.png')
        self.endDirectory()

    def insomnia(self, lite=False):
        self.addDirectoryItem('New Movie Picks', 'movies&url=ipicks', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('Creep Shows', 'movies&url=icreep', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('Space Odyssey', 'movies&url=ispace', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('Wild West', 'movies&url=iwildw', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('Docs', 'movies&url=idocs', 'insomnia.png', 'DefaultMovies.png')
        self.addDirectoryItem('Breaking Law Tv', 'tvshows&url=ibreak', 'insomnia.png', 'DefaultTVShows.png')
        self.addDirectoryItem('World of Wheels Tv', 'tvshows&url=iwow', 'insomnia.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Game of Shows Tv', 'tvshows&url=igos', 'insomnia.png', 'DefaultTVShows.png')
        self.endDirectory()

    def dococtyl(self, lite=False):
        self.addDirectoryItem('70s Sci-fi', 'movies&url=dosyfy', 'dococtyl.png', 'DefaultMovies.png')
        self.addDirectoryItem('At the Drive-in', 'movies&url=dodrivein', 'dococtyl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Parallel Universe', 'movies&url=douniverse', 'dococtyl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Planet of the Apes', 'movies&url=dopota', 'dococtyl.png', 'DefaultMovies.png')
        self.addDirectoryItem('Time Travel', 'movies&url=dotimetravel', 'dococtyl.png', 'DefaultMovies.png')
        self.endDirectory()

    def burninu(self, lite=False):
        self.addDirectoryItem('BurninU Movies', 'movies&url=bumovies', 'burninu.png', 'DefaultMovies.png')
        self.endDirectory()

    #def dcmarvelbuild(self, lite=False):
        #self.addDirectoryItem('DcMarvelBuild 4K', 'movies&url=dcmarvelbuild', 'dcmarvelbuild.png', 'DefaultVideoPlaylists.png')
        #self.endDirectory()

    def dcmarvelherosNavigator(self, lite=False):
        self.addDirectoryItem('[COLOR springgreen]Provided by[/COLOR] [COLOR red]Dc[/COLOR]v[COLOR white]Marvel[/COLOR][COLOR blue]Build[/COLOR]', 'dcmarvelherosNavigator', 'dcmarvelbuild.png', 'DefaultVideoPlaylists.png')
        self.addDirectoryItem('[COLOR red]DC Universe[/COLOR]', 'movies&url=dcmovies', 'dcmarvelheros.png', 'DefaultVideoPlaylists.png')
        self.addDirectoryItem('[COLOR white]Marvel Universe[/COLOR]', 'movies&url=marvelmovies', 'dcmarvelheros.png', 'DefaultVideoPlaylists.png')
        self.addDirectoryItem('[COLOR blue]SuperHeros[/COLOR]', 'movies&url=superhero', 'dcmarvelheros.png', 'DefaultVideoPlaylists.png')
        self.endDirectory()

    def imdbnavigator(self, lite=False):
        self.addDirectoryItem('IMDB Movies List(s)', 'imdbmovies', 'icon.png', 'DefaultMovies.png')
        #self.addDirectoryItem('IMDB TV Shows List(s)', 'imdbtvshows', 'icon.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.intheater'):
            self.addDirectoryItem(32421 if self.indexLabels else 32420, 'movies&url=theaters', 'imdb.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.featured'):
            self.addDirectoryItem(32447 if self.indexLabels else 32446, 'movies&url=featured', 'imdb.png' if self.iconLogos else 'movies.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.boxoffice'):
            self.addDirectoryItem(32435 if self.indexLabels else 32434, 'movies&url=imdbboxoffice', 'imdb.png' if self.iconLogos else 'box-office.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.certificates'):
            self.addDirectoryItem(32464 if self.indexLabels else 32463, 'movieCertificates', 'imdb.png' if self.iconLogos else 'certificates.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.genres'):
            self.addDirectoryItem(32456 if self.indexLabels else 32455, 'movieGenres', 'imdb.png' if self.iconLogos else 'genres.png', 'DefaultGenre.png')
        if control.getMenuEnabled('navi.movie.imdb.languages'):
            self.addDirectoryItem(32462 if self.indexLabels else 32461, 'movieLanguages', 'imdb.png' if self.iconLogos else 'languages.png', 'DefaultAddonLanguage.png')
        if control.getMenuEnabled('navi.movie.imdb.popular'):
            self.addDirectoryItem(32429 if self.indexLabels else 32428, 'movies&url=mostpopular', 'imdb.png' if self.iconLogos else 'most-popular.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.mostvoted'):
            self.addDirectoryItem(32439 if self.indexLabels else 32438, 'movies&url=mostvoted', 'imdb.png' if self.iconLogos else 'most-voted.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.oscarwinners'):
            self.addDirectoryItem(32452 if self.indexLabels else 32451, 'movies&url=oscars', 'imdb.png' if self.iconLogos else 'oscar-winners.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.oscarnominees'):
            self.addDirectoryItem(32454 if self.indexLabels else 32453, 'movies&url=oscarsnominees', 'imdb.png' if self.iconLogos else 'oscar-winners.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.imdb.people'):
            self.addDirectoryItem(32460 if self.indexLabels else 32459, 'moviePersons', 'imdb.png' if self.iconLogos else 'people.png', 'DefaultActor.png')
        if control.getMenuEnabled('navi.movie.imdb.years'):
            self.addDirectoryItem(32458 if self.indexLabels else 32457, 'movieYears', 'imdb.png' if self.iconLogos else 'years.png', 'DefaultYear.png')
        self.addDirectoryItem(33044, 'moviePerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(33042, 'movieSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def imdbmovies(self):
        self.addDirectoryItem('Abbot n Costello', 'movies&url=abbottcostello','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Jerry Lewis & Dean Martin', 'movies&url=lewismartin','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Top 100', 'movies&url=top100','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Top 250', 'movies&url=top250','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Top 1000', 'movies&url=top1000','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Rated G', 'movies&url=rated_g','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Rated PG', 'movies&url=rated_pg','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Rated PG13', 'movies&url=rated_pg13','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Rated R', 'movies&url=rated_r','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Rated NC17', 'movies&url=rated_nc17','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Best Director', 'movies&url=bestdirector','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('National Film Board', 'movies&url=national_film_board', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Dreamworks', 'movies&url=dreamworks_pictures', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Fox', 'movies&url=fox_pictures','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Paramount', 'movies&url=paramount_pictures', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('MGM', 'movies&url=mgm_pictures','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Universal', 'movies&url=universal_pictures', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Sony', 'movies&url=sony_pictures','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Warner Brothers', 'movies&url=warnerbrothers_pictures', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Amazon Prime', 'movies&url=amazon_prime','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Disney', 'movies&url=disney_pictures', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Family', 'movies&url=family_movies','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classics', 'movies&url=classic_movies','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classic Horror', 'movies&url=classic_horror','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classic Fantasy', 'movies&url=classic_fantasy', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classic Western', 'movies&url=classic_western', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classic Animation', 'movies&url=classic_animation', 'icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classic War', 'movies&url=classic_war','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('Classic Scifi', 'movies&url=classic_scifi','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('80s', 'movies&url=eighties','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('90s', 'movies&url=nineties','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('2000s', 'movies&url=twentyzeros','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('2010s', 'movies&url=twentyten','icon.png', 'DefaultMovies.png')
        self.addDirectoryItem('2020s', 'movies&url=twentytwenty','icon.png', 'DefaultMovies.png')
        self.endDirectory()

    def imdbtvshows(self):
        self.addDirectoryItem('NAME1', 'tvshows&url=usprime','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME2', 'tvshows&url=classtv','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME3', 'tvshows&url=ghostadv','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME4', 'tvshows&url=mosth','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME5', 'tvshows&url=ghosth','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME6', 'tvshows&url=paraw','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME7', 'tvshows&url=paral','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME8', 'tvshows&url=haunt','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME9', 'tvshows&url=hauntc','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME10', 'tvshows&url=deadp','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME11', 'tvshows&url=ghosta','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME12', 'tvshows&url=paran','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME13', 'tvshows&url=ghosti','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME14', 'tvshows&url=docsa','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME15', 'tvshows&url=myst','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME16', 'tvshows&url=scifi1','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME17', 'tvshows&url=userr','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME18', 'tvshows&url=mini','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME19', 'tvshows&url=pg','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME20', 'tvshows&url=famtv','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME21', 'tvshows&url=scian','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME22', 'tvshows&url=ani1','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME23', 'tvshows&url=rtv','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME24', 'tvshows&url=waltd','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME25', 'tvshows&url=dreamw','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME26', 'tvshows&url=sony3','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME27', 'tvshows&url=warnerbro1','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME28', 'tvshows&url=uni1','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME29', 'tvshows&url=fox11','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME30', 'tvshows&url=para4','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME31', 'tvshows&url=mgm5','icon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('NAME', 'tvshows&url=NAME','icon.png', 'DefaultTVShows.png')
        self.endDirectory()

    def tmdbnavigator(self):
        self.addDirectoryItem('TMDB User Movies List(s)', 'usertmdbmovies', 'mymovies.png', 'mymovies.png')
        #self.addDirectoryItem('TMDB User Tv Shows List(s)', 'usertmdbtv', 'mytvshows.png', 'mytvshows.png')# Not working
        self.addDirectoryItem('TMDB Empire Movies List(s)', 'empiremovies', 'mymovies.png', 'mymovies.png')
        #self.addDirectoryItem('TMDB Empire Tv Shows List(s)', 'empiretv', 'mytvshows.png', 'mytvshows.png')# Not working
        if control.getMenuEnabled('navi.movie.tmdb.boxoffice'):
            self.addDirectoryItem(32436 if self.indexLabels else 32434, 'tmdbmovies&url=tmdb_boxoffice', 'tmdb.png' if self.iconLogos else 'box-office.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.nowplaying'):
            self.addDirectoryItem(32423 if self.indexLabels else 32422, 'tmdbmovies&url=tmdb_nowplaying', 'tmdb.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.popular'):
            self.addDirectoryItem(32431 if self.indexLabels else 32430, 'tmdbmovies&url=tmdb_popular', 'tmdb.png' if self.iconLogos else 'most-popular.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.toprated'):
            self.addDirectoryItem(32441 if self.indexLabels else 32440, 'tmdbmovies&url=tmdb_toprated', 'tmdb.png' if self.iconLogos else 'most-voted.png', 'DefaultMovies.png')
        if control.getMenuEnabled('navi.movie.tmdb.upcoming'):
            self.addDirectoryItem(32427 if self.indexLabels else 32426, 'tmdbmovies&url=tmdb_upcoming', 'tmdb.png' if self.iconLogos else 'in-theaters.png', 'DefaultMovies.png')
        self.addDirectoryItem(33044, 'moviePerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(33042, 'movieSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def empiremovies(self):
        self.addDirectoryItem(mymovlist1, 'tmdbmovies&url=mycustommovlist1', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist2, 'tmdbmovies&url=mycustommovlist2', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist3, 'tmdbmovies&url=mycustommovlist3', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist4, 'tmdbmovies&url=mycustommovlist4', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist5, 'tmdbmovies&url=mycustommovlist5', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist6, 'tmdbmovies&url=mycustommovlist6', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist7, 'tmdbmovies&url=mycustommovlist7', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist8, 'tmdbmovies&url=mycustommovlist8', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist9, 'tmdbmovies&url=mycustommovlist9', 'movies.png', 'movies.png')
        self.addDirectoryItem(mymovlist10, 'tmdbmovies&url=mycustommovlist10', 'movies.png', 'movies.png')
        self.endDirectory()

    def empiretv(self):
        self.addDirectoryItem(mytvlist1, 'tmdbtvshows&url=mycustomtvlist1', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist2, 'tmdbtvshows&url=mycustomtvlist2', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist3, 'tmdbtvshows&url=mycustomtvlist3', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist4, 'tmdbtvshows&url=mycustomtvlist4', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist5, 'tmdbtvshows&url=mycustomtvlist5', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist6, 'tmdbtvshows&url=mycustomtvlist6', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist7, 'tmdbtvshows&url=mycustomtvlist7', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist8, 'tmdbtvshows&url=mycustomtvlist8', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist9, 'tmdbtvshows&url=mycustomtvlist9', 'tvshows.png', 'tvshows.png')
        self.addDirectoryItem(mytvlist10, 'tmdbtvshows&url=mycustomtvlist10', 'tvshows.png', 'tvshows.png')
        self.endDirectory()

    def usertmdbmovies(self):
        self.addDirectoryItem(movielist1, 'tmdbmovies&url=mycustomlist1', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist2, 'tmdbmovies&url=mycustomlist2', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist3, 'tmdbmovies&url=mycustomlist3', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist4, 'tmdbmovies&url=mycustomlist4', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist5, 'tmdbmovies&url=mycustomlist5', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist6, 'tmdbmovies&url=mycustomlist6', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist7, 'tmdbmovies&url=mycustomlist7', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist8, 'tmdbmovies&url=mycustomlist8', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist9, 'tmdbmovies&url=mycustomlist9', 'mymovies.png', 'mymovies.png')
        self.addDirectoryItem(movielist10, 'tmdbmovies&url=mycustomlist10', 'mymovies.png', 'mymovies.png')
        self.endDirectory()

    def usertmdbtv(self):
        self.addDirectoryItem(tvlist1, 'tmdbtvshows&url=mycustomlist1', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist2, 'tmdbtvshows&url=mycustomlist2', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist3, 'tmdbtvshows&url=mycustomlist3', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist4, 'tmdbtvshows&url=mycustomlist4', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist5, 'tmdbtvshows&url=mycustomlist5', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist6, 'tmdbtvshows&url=mycustomlist6', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist7, 'tmdbtvshows&url=mycustomlist7', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist8, 'tmdbtvshows&url=mycustomlist8', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist9, 'tmdbtvshows&url=mycustomlist9', 'mytvshows.png', 'mytvshows.png')
        self.addDirectoryItem(tvlist10, 'tmdbtvshows&url=mycustomlist10', 'mytvshows.png', 'mytvshows.png')
        self.endDirectory()

    def tools(self):
        self.addDirectoryItem(32510, 'cache_Navigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
        self.addDirectoryItem(32609, 'tools_openYourAccount', 'YourAccounts.png', 'DefaultAddonService.png', isFolder=False)
        if control.condVisibility('System.HasAddon(service.upnext)'):
            self.addDirectoryItem(32505, 'tools_UpNextSettings', 'UpNext.png', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem(32506, 'tools_contextLESettings', 'icon.png', 'DefaultAddonProgram.png', isFolder=False)
        #-- Providers - 4
        self.addDirectoryItem(32651, 'tools_lescrapersSettings', 'lescrapers.png', 'DefaultAddonService.png', isFolder=False)
        #self.addDirectoryItem('ResolveURL', 'resolveurlSettings&query=0.0', 'resolveURL.png', 'DefaultAddonService.png', isFolder=False)
        #self.addDirectoryItem('ResolveURL clean cache', 'cache_clearResolveURLcache', 'resolveURL.png', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem(32083, 'tools_cleanSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
        #-- General - 0
        self.addDirectoryItem(32043, 'tools_openSettings&query=0.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        #-- Navigation - 1
        self.addDirectoryItem(32362, 'tools_openSettings&query=1.1', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        #-- Playback - 3
        self.addDirectoryItem(32045, 'tools_openSettings&query=3.1', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        #-- Accounts - 7
        self.addDirectoryItem(32044, 'tools_openSettings&query=7.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        #-- Downloads - 9
        self.addDirectoryItem(32048, 'tools_openSettings&query=9.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        #-- Subtitles - 10
        self.addDirectoryItem(32046, 'tools_openSettings&query=10.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        #self.addDirectoryItem('ResolveURL', 'resolveurlSettings&query=0.0', 'resolveURL.png', 'DefaultAddonService.png', isFolder=False)
        #self.addDirectoryItem('ResolveURL clean cache', 'cache_clearResolveURLcache', 'resolveURL.png', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem(32556, 'library_Navigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
        self.addDirectoryItem(32049, 'tools_viewsNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
        self.addDirectoryItem(32361, 'tools_resetViewTypes', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.endDirectory()

    def cf(self):
        self.addDirectoryItem(32610, 'cache_clearAll', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.addDirectoryItem(32611, 'cache_clearSources', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.addDirectoryItem(32612, 'cache_clearMeta', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.addDirectoryItem(32613, 'cache_clearCache', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.addDirectoryItem(32614, 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.addDirectoryItem(32615, 'cache_clearBookmarks', 'tools.png', 'DefaultAddonService.png', isFolder=False)
        self.endDirectory()

    def library(self):
    # -- Library - 8
        self.addDirectoryItem(32557, 'tools_openSettings&query=8.0', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem(32558, 'library_update', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
        self.addDirectoryItem(32676, 'library_clean', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
        self.addDirectoryItem(32559, control.setting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
        self.addDirectoryItem(32560, control.setting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)
        if self.traktCredentials:
            self.addDirectoryItem(32561, 'library_moviesToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem(32562, 'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem(32672, 'library_moviesListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem(32673, 'library_moviesListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
        if self.tmdbSessionID:
            self.addDirectoryItem('TMDb: Import Movie Watchlist...', 'library_moviesToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem('TMDb: Import Movie Favorites...', 'library_moviesToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem('TMDb: Import Movie User list...', 'library_moviesListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
        if self.traktCredentials:
            self.addDirectoryItem(32563, 'library_tvshowsToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
            self.addDirectoryItem(32564, 'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
            self.addDirectoryItem(32674, 'library_tvshowsListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem(32675, 'library_tvshowsListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
        if self.tmdbSessionID:
            self.addDirectoryItem('TMDb: Import TV Watchlist...', 'library_tvshowsToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem('TMDb: Import TV Favorites...', 'library_tvshowsToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
            self.addDirectoryItem('TMDb: Import TV User list...', 'library_tvshowsListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
        self.endDirectory()

    def downloads(self):
        movie_downloads = control.setting('movie.download.path')
        tv_downloads = control.setting('tv.download.path')
        if len(control.listDir(movie_downloads)[0]) > 0: self.addDirectoryItem(32001, movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
        if len(control.listDir(tv_downloads)[0]) > 0: self.addDirectoryItem(32002, tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
        self.endDirectory()

    def premium_services(self):
        self.addDirectoryItem(40059, 'ad_ServiceNavigator', 'alldebrid.png', 'DefaultAddonService.png')
        self.addDirectoryItem(40057, 'pm_ServiceNavigator', 'premiumize.png', 'DefaultAddonService.png')
        self.addDirectoryItem(40058, 'rd_ServiceNavigator', 'realdebrid.png', 'DefaultAddonService.png')
        self.endDirectory()

    def alldebrid_service(self):
        if control.setting('alldebrid.token'):
            self.addDirectoryItem('All-Debrid: Cloud Storage', 'ad_CloudStorage', 'alldebrid.png', 'DefaultAddonService.png')
            self.addDirectoryItem('All-Debrid: Transfers', 'ad_Transfers', 'alldebrid.png', 'DefaultAddonService.png')
            self.addDirectoryItem('All-Debrid: Account Info', 'ad_AccountInfo', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
        else:
            self.addDirectoryItem('[I]Please visit Your Accounts for setup[/I]', 'tools_openYourAccount&amp;query=1.4', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
        self.endDirectory()

    def premiumize_service(self):
        if control.setting('premiumize.token'):
            self.addDirectoryItem('Premiumize: My Files', 'pm_MyFiles', 'premiumize.png', 'DefaultAddonService.png')
            self.addDirectoryItem('Premiumize: Transfers', 'pm_Transfers', 'premiumize.png', 'DefaultAddonService.png')
            self.addDirectoryItem('Premiumize: Account Info', 'pm_AccountInfo', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
        else:
            self.addDirectoryItem('[I]Please visit Your Accounts for setup[/I]', 'tools_openYourAccount&amp;query=1.11', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
        self.endDirectory()

    def realdebrid_service(self):
        if control.setting('realdebrid.token'):
            self.addDirectoryItem('Real-Debrid: Torrent Transfers', 'rd_UserTorrentsToListItem', 'realdebrid.png', 'DefaultAddonService.png')
            self.addDirectoryItem('Real-Debrid: My Downloads', 'rd_MyDownloads&query=1', 'realdebrid.png', 'DefaultAddonService.png')
            self.addDirectoryItem('Real-Debrid: Account Info', 'rd_AccountInfo', 'realdebrid.png', 'DefaultAddonService.png',isFolder=False )
        else:
            self.addDirectoryItem('[I]Please visit Your Accounts for setup[/I]', 'tools_openYourAccount&amp;query=1.18', 'realdebrid.png', 'DefaultAddonService.png', isFolder=False)
        self.endDirectory()

    def search(self):
        self.addDirectoryItem(33042, 'movieSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(33043, 'tvSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(33044, 'moviePerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(33045, 'tvPerson', 'imdb.png' if self.iconLogos else 'people-search.png', 'DefaultAddonsSearch.png')
        self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
        self.endDirectory()

    def views(self):
        try:
            syshandle = int(argv[1])
            control.hide()
            items = [(control.lang(32001), 'movies'), (control.lang(32002), 'tvshows'), (control.lang(32054), 'seasons'), (control.lang(32038), 'episodes') ]
            select = control.selectDialog([i[0] for i in items], control.lang(32049))
            if select == -1: return
            content = items[select][1]
            title = control.lang(32059)
            url = '%s?action=tools_addView&content=%s' % (argv[0], content)
            poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
            try: item = control.item(label=title, offscreen=True)
            except: item = control.item(label=title)
            item.setInfo(type='video', infoLabels = {'title': title})
            item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner})
            item.setProperty('IsPlayable', 'false')
            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
            control.content(syshandle, content)
            control.directory(syshandle, cacheToDisc=True)
            from resources.lib.modules import views
            views.setView(content, {})
        except:
            from resources.lib.modules import log_utils
            log_utils.error()
            return

    def accountCheck(self):
        if not self.traktCredentials and not self.imdbCredentials:
            control.hide()
            control.notification(message=32042, icon='WARNING')
            sysexit()

    def clearCacheAll(self):
        control.hide()
        if not control.yesnoDialog(control.lang(32077), '', ''): return
        try:
            def cache_clear_all():
                try:
                    from resources.lib.database import cache, providerscache, metacache
                    providerscache.cache_clear_providers()
                    metacache.cache_clear_meta()
                    cache.cache_clear()
                    cache.cache_clear_search()
                    # cache.cache_clear_bookmarks()
                    return True
                except:
                    from resources.lib.modules import log_utils
                    log_utils.error()
            if cache_clear_all():
                control.notification(message=32089)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearCacheProviders(self):
        control.hide()
        if not control.yesnoDialog(control.lang(32056), '', ''): return
        try:
            from resources.lib.database import providerscache
            if providerscache.cache_clear_providers(): control.notification(message=32090)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearCacheMeta(self):
        control.hide()
        if not control.yesnoDialog(control.lang(32076), '', ''): return
        try:
            from resources.lib.database import metacache
            if metacache.cache_clear_meta(): control.notification(message=32091)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearCache(self):
        control.hide()
        if not control.yesnoDialog(control.lang(32056), '', ''): return
        try:
            from resources.lib.database import cache
            if cache.cache_clear(): control.notification(message=32092)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearCacheSearch(self):
        control.hide()
        if not control.yesnoDialog(control.lang(32056), '', ''): return
        try:
            from resources.lib.database import cache
            if cache.cache_clear_search(): control.notification(message=32093)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearCacheSearchPhrase(self, table, name):
        control.hide()
        if not control.yesnoDialog(control.lang(32056), '', ''): return
        try:
            from resources.lib.database import cache
            if cache.cache_clear_SearchPhrase(table, name): control.notification(message=32094)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearBookmarks(self):
        control.hide()
        if not control.yesnoDialog(control.lang(32056), '', ''): return
        try:
            from resources.lib.database import cache
            if cache.cache_clear_bookmarks(): control.notification(message=32100)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def clearBookmark(self, name, year):
        control.hide()
        if not control.yesnoDialog(control.lang(32056), '', ''): return
        try:
            from resources.lib.database import cache
            if cache.cache_clear_bookmark(name, year): control.notification(title=name, message=32102)
            else: control.notification(message=33586)
        except:
            from resources.lib.modules import log_utils
            log_utils.error()

    def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
        sysaddon = argv[0] ; syshandle = int(argv[1])
        if isinstance(name, int): name = control.lang(name)
        url = '%s?action=%s' % (sysaddon, query) if isAction else query
        thumb = control.joinPath(self.artPath, thumb) if self.artPath else icon
        if not icon.startswith('Default'): icon = control.joinPath(self.artPath, icon)
        cm = []
        queueMenu = control.lang(32065)
        if queue: cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem)' % sysaddon))
        if context: cm.append((control.lang(context[0]), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
        if isSearch: cm.append(('Clear Search Phrase', 'RunPlugin(%s?action=cache_clearSearchPhrase&source=%s&name=%s)' % (sysaddon, table, quote_plus(name))))
        cm.append(('[COLOR deepskyblue]LE Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
        try: item = control.item(label=name, offscreen=True)
        except: item = control.item(label=name)
        item.addContextMenuItems(cm)
        if isPlayable: item.setProperty('IsPlayable', 'true')
        else: item.setProperty('IsPlayable', 'false')
        item.setArt({'icon': icon, 'poster': thumb, 'thumb': thumb, 'fanart': control.addonFanart(), 'banner': thumb})
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder= isFolder)

    def endDirectory(self):
        syshandle = int(argv[1])
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)